package org.cloudbr.sample.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class DatabaseConfig {
}
