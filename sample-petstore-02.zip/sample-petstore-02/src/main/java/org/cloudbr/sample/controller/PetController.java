package org.cloudbr.sample.controller;

import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.cloudbr.sample.model.NewPet;
import org.cloudbr.sample.model.Pet;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@Slf4j
@RestController
@RequestMapping("/api/v1/pet")
@Api(value = "API for perfoming operations on pet")
public class PetController {

    public ResponseEntity<Pet> create(@RequestBody @Valid NewPet pet){

    }
}
