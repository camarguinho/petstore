package org.cloudbr.sample.repository;

import org.cloudbr.sample.model.Pet;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PetRepository extends JpaRepository<Pet, Long> {
}
