package org.cloudbr.sample.mapper;

import org.cloudbr.sample.model.Entity.PetEntity;
import org.cloudbr.sample.model.NewPet;
import org.cloudbr.sample.model.Pet;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface PetMapper {

    PetEntity toDTO(NewPet newPet);
    Pet toModel(PetEntity petEntity);
}
