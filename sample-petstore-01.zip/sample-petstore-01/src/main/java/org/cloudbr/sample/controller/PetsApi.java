package org.cloudbr.sample.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.cloudbr.sample.model.NewPet;
import org.cloudbr.sample.model.Pet;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.Valid;
import java.util.List;

@Validated
public interface PetsApi {

    @Operation(summary = "", description = "Creates a new pet in the store.  Duplicates are allowed", tags={  })
    @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "pet response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Pet.class))),
    @ApiResponse(responseCode = "200", description = "unexpected error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    @RequestMapping(value = "/pets",
            produces = { "application/json" },
            consumes = { "application/json" },
            method = RequestMethod.POST)
    ResponseEntity<Pet> addPet(@Parameter(in = ParameterIn.DEFAULT, description = "Pet to add to the store", required=true, schema=@Schema()) @Valid @RequestBody NewPet body);


    @Operation(summary = "", description = "deletes a single pet based on the ID supplied", tags={  })
    @ApiResponses(value = {
    @ApiResponse(responseCode = "204", description = "pet deleted"),
    @ApiResponse(responseCode = "200", description = "unexpected error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    @RequestMapping(value = "/pets/{id}",
            produces = { "application/json" },
            method = RequestMethod.DELETE)
    ResponseEntity<Void> deletePet(@Parameter(in = ParameterIn.PATH, description = "ID of pet to delete", required=true, schema=@Schema()) @PathVariable("id") Long id);


    @Operation(summary = "", description = "Returns a user based on a single ID, if the user does not have access to the pet", tags={  })
    @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "pet response", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Pet.class))),
    @ApiResponse(responseCode = "200", description = "unexpected error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    @RequestMapping(value = "/pets/{id}",
            produces = { "application/json" },
            method = RequestMethod.GET)
    ResponseEntity<Pet> findPetById(@Parameter(in = ParameterIn.PATH, description = "ID of pet to fetch", required=true, schema=@Schema()) @PathVariable("id") Long id);


    @Operation(summary = "", description = "Returns all pets from the system that the user has access to ", tags={  })
    @ApiResponses(value = {
    @ApiResponse(responseCode = "200", description = "pet response", content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = Pet.class)))),
    @ApiResponse(responseCode = "200", description = "unexpected error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Error.class))) })
    @RequestMapping(value = "/pets",
            produces = { "application/json" },
            method = RequestMethod.GET)
    ResponseEntity<List<Pet>> findPets(@Parameter(in = ParameterIn.QUERY, description = "tags to filter by" ,schema=@Schema()) @Valid @RequestParam(value = "tags", required = false) List<String> tags, @Parameter(in = ParameterIn.QUERY, description = "maximum number of results to return" ,schema=@Schema()) @Valid @RequestParam(value = "limit", required = false) Integer limit);

}
